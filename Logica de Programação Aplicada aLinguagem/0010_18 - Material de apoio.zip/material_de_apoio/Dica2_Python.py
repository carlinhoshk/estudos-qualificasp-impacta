
lista = ["Abacaxi", 2,True,3.5,"Mamão"]
print(lista)

for i in lista:
    print(i)
